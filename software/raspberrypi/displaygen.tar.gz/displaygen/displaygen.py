from PIL import Image, ImageDraw, ImageFont
import sys,json
import time

data = json.loads(sys.argv[1])


#data={"T11":21.6,"T12":20.9,"T1":12.8,"T2":63.7,"T3":31.5,"T4":56.6,"T7":63.7,"T8":59,"T9":6.5,"C5":36,"T6":64.1,"C6":0,"T5":41.3,"C1":0,"C2":0,"C7":72,"C4":0}
folder = "/home/pi/displaygen/"
image0 = Image.open(folder + "t0.png")
image1 = Image.open(folder + "t1.png")
image2 = Image.open(folder + "t2.png")
image3 = Image.open(folder + "t3.png")
image4 = Image.open(folder + "t4.png")
image5 = Image.open(folder + "t5.png")
image6 = Image.open(folder + "t6.png")
image7 = Image.open(folder + "t7.png")




result = Image.new("RGBA", (800, 480))

result.paste(image1, (0, 0))
result.paste(image2, (200, 0))
result.paste(image3, (400, 0))
result.paste(image4, (600, 0))
result.paste(image5, (0, 240))
result.paste(image6, (200,240))
result.paste(image7, (400,240))

if data["C2"]>0:
	result.paste(image0, (0, 0), image0)
if data["C1"]>0:
	result.paste(image0, (200, 0), image0)
if data["C4"]>0 or data["C5"]>0 :
	result.paste(image0, (400, 0), image0)
if data["C7"]>0:
	result.paste(image0, (200, 240), image0)
if data["C6"]>0:
	result.paste(image0, (600, 0), image0)

draw = ImageDraw.Draw(result)

#Define text attributes
font = ImageFont.truetype(folder + "Gidole-Regular.ttf", size=50)
text_color = (0, 0, 0)  


#Add text to the image
position = (100, 180)
draw.text(position, str(data["T12"]), fill=text_color, font=font, align="center", anchor="mm")
position = (300, 180)
draw.text(position, str(data["T11"]), fill=text_color, font=font, align="center", anchor="mm")
position = (500, 180)
draw.text(position, str(data["T4"]), fill=text_color, font=font, align="center", anchor="mm")
position = (700, 180)
draw.text(position, str(data["T5"]), fill=text_color, font=font, align="center", anchor="mm")
position = (100, 420)
draw.text(position, str(data["T9"]), fill=text_color, font=font, align="center", anchor="mm")
position = (300, 420)
draw.text(position, str(data["T6"]), fill=text_color, font=font, align="center", anchor="mm")
position = (500, 420)
draw.text(position, str(data["T1"]), fill=text_color, font=font, align="center", anchor="mm")

accu = 0
Ttampon = data["T5"]
if Ttampon < 27:
	accu = 0
elif Ttampon > 65:
	accu = 100
else:
	accu = int(2.64*Ttampon-71)
	
position = (700, 80)
font = ImageFont.truetype(folder + "Gidole-Regular.ttf", size=26)
draw.text(position, str(accu)+"%", fill=text_color, font=font, align="center", anchor="mm")


position = (700, 420)
draw.text(position, time.strftime('%H:%M:%S'), fill=text_color, font=font, align="center")



#white_bg = Image.new("RGBA", (800, 480), "WHITE")
#result = Image.alpha_composite(white_bg, result)
#result = result.convert('1')
result.save(folder + "display.png")
#result.show()

